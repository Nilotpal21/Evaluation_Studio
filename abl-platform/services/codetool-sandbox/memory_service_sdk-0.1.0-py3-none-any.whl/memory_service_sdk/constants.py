import os
BASE_URL = "http://agentic-design"
SET_MEMORY_CONTENT_ENDPOINT = "api/internal/memory"
GET_SINGLE_MEMORY_CONTENT_ENDPOINT = "api/internal/memory"
DELETE_SINGLE_MEMORY_CONTENT_ENDPOINT = "api/internal/memory"
SEARCH_MEMORY_CONTENT_ENDPOINT = "api/internal/memory"