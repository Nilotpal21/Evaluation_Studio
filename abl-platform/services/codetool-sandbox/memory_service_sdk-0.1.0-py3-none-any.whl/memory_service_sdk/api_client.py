"""API client for making HTTP requests."""
from typing import Dict, Optional, Any, List, Literal, Union
import json
import requests
from requests import Response
from requests.exceptions import RequestException, HTTPError, ConnectionError as RequestsConnectionError
from .logger import logger
from .exceptions import (
    APIError, AuthenticationError, AuthorizationError, ResourceNotFoundError,
    ResourceConflictError, ServerError, ConnectionError, ValidationError, RateLimitError
)
from .constants import BASE_URL


class APIClient:
    """
    Unified API client for making authorized HTTP requests.
    Automatically attaches user_id, account_id, and app_id if provided.
    Supports GET, POST, and DELETE requests.
    """

    def __init__(self, jwt: str, base_url: str):
        self._jwt = jwt
        self._base_url = base_url

        self._headers = {
            'Content-Type': 'application/json',
            "Authorization": f"bearer {self._jwt}",
            "apiKey": ""
        }
        logger.debug("API client initialized")

    def _prepare_url(self, endpoint: str, **path_params) -> str:
        """Prepare the full URL with path parameters."""
        try:
            formatted_endpoint = endpoint.format(**path_params)
        except KeyError as e:
            logger.error("Missing path parameter: %s", str(e))
            raise ValidationError(f"Missing path parameter: {e}")

        url = f"{self._base_url}/{formatted_endpoint.strip('/')}"
        logger.debug("Prepared URL: %s", url)
        return url

    def _handle_error_response(self, response: Response, url: str) -> None:
        """Handle error responses from the API."""
        status_code = response.status_code
        error_msg = f"HTTP {status_code} Error for URL {url}: {response.text}"

        try:
            error_data = response.json()
        except ValueError:
            error_data = {"errors": [response.text]}

        logger.error("API error: %s", error_msg)

        if status_code == 400:
            raise ValidationError(error_msg, status_code, error_data)
        elif status_code == 401:
            raise AuthenticationError(error_msg, status_code, error_data)
        elif status_code == 403:
            raise AuthorizationError(error_msg, status_code, error_data)
        elif status_code == 404:
            raise ResourceNotFoundError(error_msg, status_code, error_data)
        elif status_code == 409:
            raise ResourceConflictError(error_msg, status_code, error_data)
        elif status_code == 429:
            raise RateLimitError(error_msg, status_code, error_data)
        elif status_code >= 500:
            raise ServerError(error_msg, status_code, error_data)
        else:
            raise APIError(error_msg, status_code, error_data)

    def post(
            self,
            endpoint: str,
            body: Any = None,
            **path_params
    ) -> Dict:
        """Make a POST request to the API."""
        url = self._prepare_url(endpoint=endpoint, **path_params)
        logger.debug("Making POST request to %s with body: %s", url, json.dumps(body))

        try:
            response = requests.post(url, headers=self._headers, json=body)

            if response.ok:
                logger.debug("Successful POST response from %s", url)
                return response.json()

            self._handle_error_response(response, url)

        except RequestsConnectionError as e:
            logger.error("Connection error during POST request: %s", str(e))
            raise ConnectionError(f"Failed to connect to {url}: {str(e)}")
        except RequestException as e:
            logger.error("Request error during POST request: %s", str(e))
            raise APIError(f"Request failed: {str(e)}")


