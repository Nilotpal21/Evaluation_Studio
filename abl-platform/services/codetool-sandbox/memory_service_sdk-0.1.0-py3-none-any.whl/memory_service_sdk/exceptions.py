"""Custom exceptions for the SDK."""
from typing import Optional, Dict, Any

class MemorySDKError(Exception):
    """Base exception for all SDK errors."""
    def __init__(self, message: str, details: Optional[Dict[str, Any]] = None):
        super().__init__(message)
        self.details = details or {}

class APIError(MemorySDKError):
    """Base class for API-related errors."""
    def __init__(
        self,
        message: str,
        status_code: Optional[int] = None,
        response_body: Optional[Dict[str, Any]] = None
    ):
        details = {
            "status_code": status_code,
            "response_body": response_body
        }
        super().__init__(message, details)
        self.status_code = status_code
        self.response_body = response_body

class ValidationError(APIError):
    """Raised when input validation fails."""
    pass

class AuthenticationError(APIError):
    """Raised when authentication fails."""
    pass

class AuthorizationError(APIError):
    """Raised when the user lacks permission."""
    pass

class ResourceNotFoundError(APIError):
    """Raised when a requested resource is not found."""
    pass

class ResourceConflictError(APIError):
    """Raised when there's a conflict with existing resources."""
    pass

class RateLimitError(APIError):
    """Raised when API rate limit is exceeded."""
    pass

class ServerError(APIError):
    """Raised when the server encounters an error."""
    pass

class ConnectionError(MemorySDKError):
    """Raised when network connection fails."""
    pass

class ConfigurationError(MemorySDKError):
    """Raised when SDK is improperly configured."""
    pass