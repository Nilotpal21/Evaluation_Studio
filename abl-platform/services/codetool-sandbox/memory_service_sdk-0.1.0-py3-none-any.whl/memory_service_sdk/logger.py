"""Logging configuration for the SDK."""
import logging
import sys
from typing import Optional


def setup_logger(
        name: str = "memory_service_sdk",
        level: int = logging.INFO,
        log_format: Optional[str] = None
) -> logging.Logger:
    """
    Configure and return a logger instance.

    Args:
        name: Logger name
        level: Logging level (default: INFO)
        log_format: Custom log format string (optional)

    Returns:
        logging.Logger: Configured logger instance
    """
    if not log_format:
        log_format = (
            "%(asctime)s - %(name)s - %(levelname)s - %(message)s"
        )

    logger = logging.getLogger(name)
    logger.setLevel(level)

    # Avoid duplicate handlers
    if not logger.handlers:
        handler = logging.StreamHandler(sys.stdout)
        handler.setFormatter(logging.Formatter(log_format))
        logger.addHandler(handler)

    return logger


# Create default logger instance
logger = setup_logger()