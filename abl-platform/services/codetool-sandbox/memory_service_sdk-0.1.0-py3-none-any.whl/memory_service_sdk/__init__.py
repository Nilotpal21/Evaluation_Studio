"""
Memory Service SDK
~~~~~~~~~~~~~~~~~

A Python SDK for interacting with the Memory Content Service.

This SDK provides a high-level interface for managing memory stores and their content,
with features including:

- Memory store creation and management
- Content storage and retrieval
- Namespace management
- Retention policy configuration
"""
from .memory_content_manager import MemoryContentManager
from .api_client import APIClient
from .exceptions import (
    MemorySDKError, APIError, ValidationError, AuthenticationError,
    AuthorizationError, ResourceNotFoundError, ResourceConflictError,
    RateLimitError, ServerError, ConnectionError, ConfigurationError
)
from .logger import logger, setup_logger

__version__ = "0.1.0"

__all__ = [
    # Main classes
    "MemoryContentManager",
    "APIClient",

    # Exceptions
    "MemorySDKError",
    "APIError",
    "ValidationError",
    "AuthenticationError",
    "AuthorizationError",
    "ResourceNotFoundError",
    "ResourceConflictError",
    "RateLimitError",
    "ServerError",
    "ConnectionError",
    "ConfigurationError",

    # Logging
    "logger",
    "setup_logger",

    # Version info
    "__version__"
]

# Configure default logger
logger.debug("Memory Service SDK version %s initialized", __version__)
