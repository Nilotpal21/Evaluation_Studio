"""Memory store manager for creating and managing memory stores."""
from typing import Dict, Optional, Any, List, Literal, Union
from .logger import logger
from .api_client import APIClient
from .constants import (SEARCH_MEMORY_CONTENT_ENDPOINT, SET_MEMORY_CONTENT_ENDPOINT,
                        GET_SINGLE_MEMORY_CONTENT_ENDPOINT,
                        DELETE_SINGLE_MEMORY_CONTENT_ENDPOINT)


class ReadOnlyDescriptor:
    """A descriptor that makes an attribute read-only after initialization.
    This is used to prevent the api_client attribute from being modified after initialization.
    """
    def __init__(self, name):
        self.name = f"__{name}"
    
    def __get__(self, instance, owner):
        if instance is None:
            return self
        return getattr(instance, self.name)
    
    def __set__(self, instance, value):
        if hasattr(instance, self.name):
            raise AttributeError(f"Can't modify {self.name} after initialization")
        setattr(instance, self.name, value)


class MemoryContentManager:
    """
    Manages memory content lifecycle operations (create, get, delete).
    """
    api_client = ReadOnlyDescriptor('api_client')

    def __init__(self, api_client: APIClient):
        self.api_client = api_client
        logger.info("Memory content manager initialized")

    def set_content(self, memory_store_name: str, content: dict):
        """
        Set content in the provided memory store.

        Args:
            memory_store_name: Memory Store name fow which content should be created
            content: Content to store

        Returns:
            dict: API response

        Raises:
            APIError: If the API request fails
        """
        logger.info("Setting content in store: %s", memory_store_name)

        payload = {
            "action": "set",
            "memoryStoreName": memory_store_name,
            "payload": {"content": content},
        }

        logger.debug("Setting content with payload: %s", payload)

        try:
            response = self.api_client.post(endpoint=SET_MEMORY_CONTENT_ENDPOINT, body=payload)
            if response["success"]:
                logger.info("Successfully set content")
                return {"success": True}
            else:
                logger.error("Failed to set content: %s", str(response["error"]))
                return {"success": False, "error": response["error"]}

        except Exception as e:
            logger.error("Error in setting content: %s", str(e))
            response = e.response_body["errors"]
            return {"success": False, "error": response}

    def get_content(self, memory_store_name: str, projections: Optional[dict] = None):
        """
        Directly retrieves the stored content.

        Args:
            memory_store_name: Memory Store name from which content should be fetched.
            projections: projections to filter response fields

        Returns:
            dict: Retrieved content

        Raises:
            ResourceNotFoundError: If content is not found
            APIError: If the API request fails
        """
        logger.info("Getting content from store: %s", memory_store_name)

        payload = {
            "action": "get",
            "memoryStoreName": memory_store_name,
        }

        if projections:
            payload["projections"] = str(projections)

        logger.debug("Getting content with payload: %s", payload)

        try:
            response = self.api_client.post(endpoint=GET_SINGLE_MEMORY_CONTENT_ENDPOINT, body=payload)
            if response["success"]:
                logger.info("Successfully retrieved content")
                return response["data"]["content"]
            else:
                logger.error("Failed to get content: %s", str(response["error"]))
                return {"success": False, "error": response["error"]}

        except Exception as e:
            logger.error("Error in getting content: %s", str(e))
            response = e.response_body["errors"]
            return {"success": False, "error": response}

    def delete_content(self, memory_store_name: str):
        """
        Delete a content from the store.

        Args:
            memory_store_name: Memory Store name for which content should be deleted.

        Returns:
            dict: API response

        Raises:
            ResourceNotFoundError: If content is not found
            APIError: If the API request fails
        """
        logger.info("Deleting content from store: %s", memory_store_name)

        payload = {
            "action": "delete",
            "memoryStoreName": memory_store_name,
        }

        logger.debug("Deleting content with payload: %s", payload)

        try:
            response = self.api_client.post(endpoint=DELETE_SINGLE_MEMORY_CONTENT_ENDPOINT, body=payload)

            if response["success"]:
                logger.info("Successfully deleted content from store: %s", memory_store_name)
                return {"success": True}
            else:
                logger.error("Failed to delete content: %s", str(response["error"]))
                return {"success": False, "error": response["error"]}

        except Exception as e:
            logger.error("Error in deleting content: %s", str(e))
            response = e.response_body["errors"]
            return {"success": False, "error": response}

    def get(self, memory_store_name: str, record_key: str, projections: Optional[dict] = None):
        """
        Get a content from the store.

        Args:
            memory_store_name: Memory Store name from which content should be fetched.
            record_key: Key of the content to be fetched.
            projections: projections to filter response fields
            
        Returns:
            dict: Retrieved content
        """
        logger.info("Getting content from store: %s with key: %s", memory_store_name, record_key)

        payload = {
            "action": "get",
            "memoryStoreName": memory_store_name,
            "key": record_key,
        }

        if projections:
            payload["projections"] = str(projections)

        logger.debug("Getting content with payload: %s", payload)

        try:
            response = self.api_client.post(endpoint=GET_SINGLE_MEMORY_CONTENT_ENDPOINT, body=payload)
            if response["success"]:
                logger.info("Successfully retrieved content")
                return response["data"]["content"]
            else:
                logger.error("Failed to get content: %s", str(response["error"]))
                return {"success": False, "error": response["error"]}
        except Exception as e:
            logger.error("Error in getting content: %s", str(e))
            response = e.response_body["errors"]
            return {"success": False, "error": response}

    def set(self, memory_store_name: str, record_key: str, content: dict):
        """
        Set a content in the store.

        Args:
            memory_store_name: Memory Store name in which content should be set.
            record_key: Key of the content to be set.
            content: Content to be set.
        Returns:
            dict: API response

        Raises:
            APIError: If the API request fails
        """
        logger.info("Setting content in store: %s with key: %s", memory_store_name, record_key)
        payload = {
            "action": "set",
            "memoryStoreName": memory_store_name,
            "key": record_key,
            "payload": {"content": content},
        }

        logger.debug("Setting content with payload: %s", payload)

        try:
            response = self.api_client.post(endpoint=SET_MEMORY_CONTENT_ENDPOINT, body=payload)
            if response["success"]:
                logger.info("Successfully set content")
                return {"success": True}
            else:
                logger.error("Failed to set content: %s", str(response["error"]))
                return {"success": False, "error": response["error"]}
        except Exception as e:
            logger.error("Error in setting content: %s", str(e))
            response = e.response_body["errors"]
            return {"success": False, "error": response}

    def update(self, memory_store_name: str, record_key: str, content: dict, patchMode: str = "merge", upsert: bool = False):
        """
        Update a content in the store.

        Args:
            memory_store_name: Memory Store name in which content should be updated.
            record_key: Key of the content to be updated.
            content: Content to be updated.
            patchMode: Patch mode to use for updating the content. (merge, overwrite)
            upsert: Whether to upsert the content if it does not exist.
        Returns:
            dict: API response

        Raises:
            APIError: If the API request fails
        """
        logger.info("Updating content in store: %s with key: %s", memory_store_name, record_key)
        payload = {
            "action": "update",
            "memoryStoreName": memory_store_name,
            "key": record_key,
            "payload": {"content": content},
            "patchMode": patchMode,
            "upsert": upsert,
        }

        logger.debug("Updating content with payload: %s", payload)
        try:
            response = self.api_client.post(endpoint=SET_MEMORY_CONTENT_ENDPOINT, body=payload)
            if response["success"]:
                logger.info("Successfully updated content")
                return {"success": True}
            else:
                logger.error("Failed to update content: %s", str(response["error"]))
                return {"success": False, "error": response["error"]}
        except Exception as e:
            logger.error("Error in updating content: %s", str(e))
            response = e.response_body["errors"]
            return {"success": False, "error": response}

    def delete(self, memory_store_name: str, record_key: str):
        """
        Delete a content from the store.

        Args:
            memory_store_name: Memory Store name for which content should be deleted.
            record_key: Key of the content to be deleted.
        Returns:
            dict: API response

        Raises:
            APIError: If the API request fails
        """
        logger.info("Deleting content from store: %s with key: %s", memory_store_name, record_key)
        payload = {
            "action": "delete",
            "memoryStoreName": memory_store_name,
            "key": record_key,
        }

        logger.debug("Deleting content with payload: %s", payload)
        try:
            response = self.api_client.post(endpoint=DELETE_SINGLE_MEMORY_CONTENT_ENDPOINT, body=payload)
            if response["success"]:
                logger.info("Successfully deleted content")
                return {"success": True}
            else:
                logger.error("Failed to delete content: %s", str(response["error"]))
                return {"success": False, "error": response["error"]}
        except Exception as e:
            logger.error("Error in deleting content: %s", str(e))
            response = e.response_body["errors"]
            return {"success": False, "error": response}

    def search(self, query: str, memory_store_name: str, search_mode: Literal["semantic", "keyword", "hybrid"] = "semantic", top_k: int = 10, filters: Optional[dict] = None, options: Optional[dict] = None):
        """
        Search in the store

        Args:
            query: Search query string
            memory_store_name: Memory Store name for which content should be deleted.
            search_mode: Search mode to use for the search. (semantic, keyword, hybrid)
            top_k: Number of results to return
            filters: Filters to apply to the search
            options: Options to apply to the search
        Returns:
            dict: API response

        Raises:
            APIError: If the API request fails
        """

        logger.info("Searching content from store: %s for query: %s", memory_store_name, query)
        payload = {
            "action": "search",
            "query": query,
            "memoryStoreName": memory_store_name,
            "searchType": search_mode,
        }

        if filters:
            payload["filters"] = filters

        if options:
            payload["options"] = options
            payload["options"]["topK"] = top_k
        else:
            payload["options"] = {
                "topK": top_k,
            }

        

        logger.debug("Searching with payload: %s", payload)
        try:
            response = self.api_client.post(endpoint=SEARCH_MEMORY_CONTENT_ENDPOINT, body=payload)
            if response["success"]:
                logger.info("Successfully completed the search")
                return response["data"]
            else:
                logger.error("Failed to search content: %s", str(response["error"]))
                return {"success": False, "error": response["error"]}
        except Exception as e:
            logger.error("Error in searching content: %s", str(e))
            response = e.response_body["errors"]
            return {"success": False, "error": response}