from contextvars import ContextVar

LOG_CONTEXT: ContextVar[dict] = ContextVar("log_context", default={})

