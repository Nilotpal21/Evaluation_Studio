import logging
import json
from datetime import datetime, timezone
import uuid
import time
import os
from opentelemetry import trace
from opentelemetry.exporter.otlp.proto.http.trace_exporter import OTLPSpanExporter
from opentelemetry.sdk.resources import Resource
from opentelemetry.sdk.trace import TracerProvider
from opentelemetry.sdk.trace.export import ConsoleSpanExporter, BatchSpanProcessor

from .context import get_log_context

class KoreLogger:
    def __init__(self):
        
        # Set up basic logging
        logging.basicConfig(level=logging.INFO)
        logging.getLogger("opentelemetry.attributes").setLevel(logging.DEBUG)
        self.logger = logging.getLogger(__name__)

        self.log_destination = 'stdout'
        self.otel_endpoint = os.environ.get('OTEL_ENDPOINT', 'http://localhost:4317')
        self.tracer = None
        self.logger.debug(f"log destination: {self.log_destination}")
    
    def set_log_level(self, log_level):
        self.logger.setLevel(log_level)

    def setup_opentelemetry(self, otel_config):
        self.log_destination = 'otel'
        self.otel_endpoint = otel_config.get('endpoint', 'http://localhost:4317')

        resource = Resource(attributes={
            "service.name": otel_config.get('service_name', 'LOG_SOURCE'),
            "service.instance.id": otel_config.get('pod_id', 'POD_ID'),
            "deployment.environment": otel_config.get('environment', 'GALE_ENV')
        })
        
        tracer_provider = TracerProvider(resource=resource)
        otlp_exporter = ConsoleSpanExporter() if otel_config.get('environment') == 'rnd-gale.kore.ai' else OTLPSpanExporter(endpoint=self.otel_endpoint)
        self.logger.debug(f"otlp_exporter: {otlp_exporter}")
        span_processor = BatchSpanProcessor(otlp_exporter)
        tracer_provider.add_span_processor(span_processor)
        trace.set_tracer_provider(tracer_provider)
        self.tracer = trace.get_tracer(__name__)
        self.logger.debug(f"log destination: {self.log_destination}")
        self.logger.debug(f"tracer: {self.tracer}")
    
    def log(self, message, log_level, stack_trace=None):
        log_entry = {
            "logLevel": log_level,
            "meta": {
                "log_pid": os.getpid(),
                "log_id": f"cse-{str(uuid.uuid4())}",
                "stack_trace": stack_trace
            },
            "unixtimestamp": int(datetime.timestamp(datetime.now()) * 1000),   # Current timestamp in milliseconds
            "timestamp": datetime.fromtimestamp(time.time(), tz=timezone.utc).strftime("%Y-%m-%dT%H:%M:%SZ")
        }

        stdout = True

        if self.log_destination == 'otel' and self.tracer:
            context = get_log_context()
            if context.get("debug") is False:
                stdout = False
                self.logger.debug(f"context: {context}")
                with self.tracer.start_as_current_span(f"custom_script_logs") as span:
                    for key, value in context.items():
                        if key != "debug":
                            span.set_attribute(key, value)
                        
                    # Add log attributes to the span
                    span.set_attribute("log_message", message)
                    span.set_attribute("log_level", log_level)
                    span.set_attribute("log_trace_id", context.get("traceparent"))
                    for key, value in log_entry["meta"].items():
                        if value is not None:  # Skip None values
                            span.set_attribute(key, str(value))

        return stdout

    def debug(self, message):
        stdout = self.log(message, "Debug")
        if stdout:
            print(f"DEBUG :: {message}")  # Print statements are added here so that they can be captured as stdout in function execution logs

    def info(self, message):
        stdout = self.log(message, "Info")
        if stdout:
            print(f"INFO :: {message}")

    def warning(self, message):
        stdout = self.log(message, "Warning")
        if stdout:
            print(f"WARNING :: {message}")

    def error(self, message, stack_trace=None):
        stdout = self.log(message, "Error", stack_trace)
        if stdout:
            print(f"ERROR :: {message}")

    def stdout(self, message):
        _ = self.log(message, "Stdout")

    def stderr(self, message):
        _ = self.log(message, "Stderr")
