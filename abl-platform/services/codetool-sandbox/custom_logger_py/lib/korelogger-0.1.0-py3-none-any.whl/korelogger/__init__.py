from .context import set_log_context, get_log_context
from .logger import KoreLogger

korelogger = KoreLogger()

def set_log_level(log_level):
    korelogger.set_log_level(log_level)

def setup_otel(otel_config):
    korelogger.setup_opentelemetry(otel_config)

def debug(message):
    return korelogger.debug(message)

def info(message):
    return korelogger.info(message)

def warning(message):
    return korelogger.warning(message)

def error(message, stack_trace=None):
    return korelogger.error(message, stack_trace)

def stdout(message):
    return korelogger.stdout(message)

def stderr(message):    
    return korelogger.stderr(message)

__all__ = ["debug", "info", "warning", "error", "stdout", "stderr", "set_log_context", "get_log_context", "setup_otel", "set_log_level"]

