from ._context_holder import LOG_CONTEXT

def set_log_context(**kwargs):
    LOG_CONTEXT.set(kwargs)

def get_log_context():
    ctx = LOG_CONTEXT.get()
    return ctx
